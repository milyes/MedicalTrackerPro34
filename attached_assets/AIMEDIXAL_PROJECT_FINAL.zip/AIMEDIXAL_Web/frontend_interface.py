
# frontend_interface.py - Streamlit interface

import streamlit as st
import pandas as pd
import requests
import matplotlib.pyplot as plt

st.title("AIMEDIXAL - Analyse Parkinson")

uploaded_file = st.file_uploader("Sélectionnez un fichier CSV", type=["csv"])
if uploaded_file is not None:
    df = pd.read_csv(uploaded_file)
    st.line_chart(df["amplitude"])
    response = requests.post("http://localhost:8000/analyze/", files={"file": uploaded_file.getvalue()})
    if response.ok:
        result = response.json()
        st.success(f"Résultat : {result['result']}")
        st.write(f"Amplitude maximale : {result['max_amplitude']}")

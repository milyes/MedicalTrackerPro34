
# main.py - FastAPI backend for AIMEDIXAL

from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
import pandas as pd

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/analyze/")
async def analyze_file(file: UploadFile = File(...)):
    contents = await file.read()
    df = pd.read_csv(pd.compat.StringIO(contents.decode()))
    # Dummy result: check if amplitude exceeds threshold
    result = "Symptômes détectés" if df["amplitude"].max() > 0.5 else "Aucun symptôme détecté"
    return {"result": result, "max_amplitude": df["amplitude"].max()}

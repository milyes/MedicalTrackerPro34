
import 'package:flutter/material.dart';

class DashboardScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Analyse Parkinson')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(onPressed: () {}, child: Text("Choisir un fichier")),
            SizedBox(height: 20),
            ElevatedButton(onPressed: () {}, child: Text("Analyser")),
            SizedBox(height: 20),
            Text("Résultat : ..."),
            SizedBox(height: 20),
            ElevatedButton(onPressed: () {}, child: Text("Générer PDF")),
          ],
        ),
      ),
    );
  }
}

#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$(dirname "$0")"

if [ ! -d venv ]; then
    python -m venv venv
fi
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

[ -f gunicorn.pid ] && kill -9 $(cat gunicorn.pid) && rm gunicorn.pid
nohup gunicorn -w 2 -k uvicorn.workers.UvicornWorker app:app             --bind 0.0.0.0:5000 --access-logfile - > gunicorn.out 2>&1 &
echo $! > gunicorn.pid
echo "✅ Intelligence lancé sur http://0.0.0.0:5000"

from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from datetime import timedelta
import os

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///db.sqlite3"
app.config["JWT_SECRET_KEY"] = os.environ.get("JWT_SECRET_KEY", "super-secret-key")
app.config["JWT_ACCESS_TOKEN_EXPIRES"] = timedelta(days=1)

db = SQLAlchemy(app)
jwt = JWTManager(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)

class History(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, nullable=False)
    question = db.Column(db.String, nullable=False)
    answer = db.Column(db.String, nullable=False)

@app.before_first_request
def create_tables():
    db.create_all()

@app.route("/api/register", methods=["POST"])
def register():
    data = request.get_json()
    user = User(username=data["username"], password=data["password"])
    db.session.add(user)
    db.session.commit()
    return jsonify(msg="User registered")

@app.route("/api/login", methods=["POST"])
def login():
    data = request.get_json()
    user = User.query.filter_by(username=data["username"], password=data["password"]).first()
    if not user:
        return jsonify(msg="Bad credentials"), 401
    access_token = create_access_token(identity=user.id)
    return jsonify(access_token=access_token)

@app.route("/api/question", methods=["POST"])
@jwt_required()
def question():
    user_id = get_jwt_identity()
    question = request.json.get("question")
    answer = f"Réponse IA simulée : '{question[::-1]}'"  # Reverse string as mock
    h = History(user_id=user_id, question=question, answer=answer)
    db.session.add(h)
    db.session.commit()
    return jsonify(answer=answer)

@app.route("/api/history", methods=["GET"])
@jwt_required()
def history():
    user_id = get_jwt_identity()
    records = History.query.filter_by(user_id=user_id).all()
    return jsonify(history=[{"q": r.question, "a": r.answer} for r in records])

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
